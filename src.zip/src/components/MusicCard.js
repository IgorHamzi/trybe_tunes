import React, { Component } from 'react';

export default class MusicCard extends Component {
  render() {
    return (
      <div> </div>
    );
  }
}
