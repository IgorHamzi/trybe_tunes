import React, { Component } from 'react';

export default class Load extends Component {
  render() {
    return (
      <div>
        <h1>Carregando...</h1>
      </div>
    );
  }
}
