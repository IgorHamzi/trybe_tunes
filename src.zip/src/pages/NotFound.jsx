import React, { Component } from 'react';

export default class NotFound extends Component {
  render() {
    return (
      <div data-testid="page-not-found">
        oi
      </div>
    );
  }
}
